
#ifndef _H_SIMD
#define _H_SIMD

extern void AddSimdTypes();

#endif
