
/* prototypes of functions defined in elf.c */

#ifndef _ELF_H_INCLUDED_
#define _ELF_H_INCLUDED_

extern void     elf_init( struct module_info * );

#endif // _ELF_H_INCLUDED_
