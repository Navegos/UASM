
#ifndef ATOFLOAT_H
#define ATOFLOAT_H

extern void atofloat( void *, const char *, unsigned, bool, uint_8 );

#endif
