#pragma once

extern int get_pseudoCMPXX(char* , char* , int );
extern int get_pseudoVCMPXX(char*, char*, int);
extern int get_pseudoPCLMULXX(char*, char*, int);
extern int get_pseudoVPCLMULXX(char*, char*, int);
