
#ifndef _MACROLIB_H_
#define _MACROLIB_H_

extern void Adddefs(void);
extern void CreateMacroLibCases(void);

#endif